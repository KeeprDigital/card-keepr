from pathlib import Path
import subprocess
root=Path('/tmp/card-keepr-253-resolve-20260911')
backup=Path('src/catalogue/backup-recovery/backup-recovery.ts')
test=Path('apps/ingestion/test/reconciliation-scale.stress.spec.ts')
helper=Path("apps/ingestion/test/native-publication-helpers.ts")
original={p:p.read_text() for p in [backup,test,helper]}
try:
 h=original[helper].replace('const id = requiredString(candidate, "id");', 'const ownerMeasureStart=Date.now(); const id = requiredString(candidate, "id");')
 h=h.replace('expect(prepared.response.status, JSON.stringify(prepared.document)).toBe(202);', 'console.info("[PROFILE-253-owner]", "private", Date.now()-ownerMeasureStart); expect(prepared.response.status, JSON.stringify(prepared.document)).toBe(202);')
 h=h.replace('expect(approved.response.status, JSON.stringify(approved.document)).toBe(202);', 'console.info("[PROFILE-253-owner]", "public-and-backup", Date.now()-ownerMeasureStart); expect(approved.response.status, JSON.stringify(approved.document)).toBe(202);')
 helper.write_text(h)
 s=original[backup].replace('const expectedVerification = { ...capturedVerification };','const expectedVerification = { ...capturedVerification };\n  const measureStart = Date.now(); console.info("[PROFILE-253-backup]", "start", measureStart);')
 for before,label in [
  ('if (!snapshot) throw new Error("Native composition snapshot is unavailable.");','snapshot'),
  ('expectedVerification.composition_snapshot = snapshot;','artifacts'),
  ('exportedBookmark = exported.bookmark;','exported'),
  ('contentSha256 = contentDigest.digest("hex");','retained'),
  ('await transitionRestoredAttempt(database, input.idempotencyKey, ownerToken);','restored'),
  ('assertCompleteRestoredVerification(restoredVerification);','verified')]:
  s=s.replace(before, 'console.info("[PROFILE-253-backup]", "'+label+'", Date.now()-measureStart);\n'+before)
 backup.write_text(s)
 s=original[test]
 start=s.index('test("a Product-heavy')
 end=s.index('\ntest(',start+5)
 body=s[start:end]
 body=body.replace('async () => {','async () => {\n const measureStart=Date.now();',1)
 for before,label in [
  ('const candidate = await prepareNativeCandidate','collected'),
  ('await candidatePartitions(candidate);','prepared'),
  ('const published = await approveNativeCandidate','partitions'),
  ('expect(published.response.status)','publication-and-backup'),
  ('const scaleProducts = products.filter','export-records')]:
  body=body.replace(before, 'console.info("[PROFILE-253-product]", "'+label+'", Date.now()-measureStart);\n'+before)
 test.write_text(s[:start]+body+s[end:])
 with (root/'product-phases-nativehash.log').open('w') as f:
  completed=subprocess.run(['pnpm','run','test:stress:full','apps/ingestion/test/reconciliation-scale.stress.spec.ts','-t','Product-heavy','--maxWorkers=1','--reporter=default','--reporter=json','--outputFile='+str(root/'product-phases-nativehash.json')],stdout=f,stderr=subprocess.STDOUT)
 print('Product phase measurement exit:',completed.returncode)
finally:
 for p,s in original.items():p.write_text(s)
