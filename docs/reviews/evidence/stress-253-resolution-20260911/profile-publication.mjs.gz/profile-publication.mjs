import { spawn } from 'node:child_process';
import { writeFileSync, openSync } from 'node:fs';
const root='/tmp/card-keepr-253-resolve-20260911';
const output=openSync(root+'/cpu-publication-profile.log','w');
const child=spawn('pnpm',['exec','vitest','run','--config','apps/ingestion/vitest.config.ts','apps/ingestion/test/reconciliation-scale.stress.spec.ts','-t','Product-heavy','--inspect=127.0.0.1:9333','--no-file-parallelism','--reporter=json','--outputFile='+root+'/cpu-publication-profile.json'],{env:{...process.env,KEEPR_TEST_SUITE:'stress'},stdio:['ignore',output,output]});
let exited=false;
const complete=new Promise(resolve=>child.on('close',code=>{exited=true;resolve(code)}));
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let targets;
while(!exited){try{targets=await (await fetch('http://127.0.0.1:9333/json/list')).json();if(targets.length)break}catch{}await sleep(100)}
if(!targets)throw new Error('No inspector target');
const target=targets.find(t=>t.id.startsWith('core:user:vitest-plugin-runner'));
const socket=new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject});
let sequence=0;const pending=new Map();
socket.onmessage=event=>{const message=JSON.parse(event.data);if(message.id){const p=pending.get(message.id);pending.delete(message.id);message.error?p?.reject(message.error):p?.resolve(message.result)}};
socket.onclose=()=>{for(const p of pending.values())p.reject(new Error('closed'));pending.clear()};
const command=(method,params={})=>new Promise((resolve,reject)=>{const id=++sequence;pending.set(id,{resolve,reject});socket.send(JSON.stringify({id,method,params}))});
await command('Profiler.enable');await command('Profiler.setSamplingInterval',{interval:1000});
await sleep(12000);
await command('Profiler.start');
await sleep(5000);
try { const {profile}=await command('Profiler.stop');writeFileSync(root+'/worker-publication.cpuprofile',JSON.stringify(profile)); } catch(error) { console.log(error.message); }
socket.close();console.log({code:await complete});
